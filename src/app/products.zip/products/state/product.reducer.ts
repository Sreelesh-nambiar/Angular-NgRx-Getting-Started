import {
  Product
} from '../product';
import * as fromRoot from "../../state/app.state";
import {
  createFeatureSelector,
  createSelector
} from '@ngrx/store';
import {
  ProductActions,
  ProductActionType
} from './product.actions';

export interface State extends fromRoot.State {
  products: ProductState;
}

export interface ProductState {
  showProductCode: boolean;
  products: Product[];
  currentProductId: number | null;
  error: string
}

const iniitialState: ProductState = {
  showProductCode: true,
  products: [],
  currentProductId: null,
  error: ''
}

const getProductFeaturestate = createFeatureSelector < ProductState > ('products');

export const getShowProductCode = createSelector(
  getProductFeaturestate, state => state.showProductCode
);

export const getCurrentProductId = createSelector(
  getProductFeaturestate, state => state.currentProductId
);

// export const getCurrentProduct = createSelector(
//   getProductFeaturestate,
//   getCurrentProductId, (state, currentProductId) => state.products.find(p => p.id === currentProductId)
// );

// export const getCurrentProduct = createSelector(
//     getProductFeaturestate,
//     state => state.currentProduct
//   );

export const getCurrentProduct = createSelector(
  getProductFeaturestate,
  getCurrentProductId,
  (state, currentProductId) => {
    if (currentProductId === 0) {
      return {
        id: 0,
        productName: '',
        productCode: 'new',
        description: '',
        starRating: 0
      };
    } else {
      return currentProductId ? state.products.find(p => p.id === currentProductId) : null;
    }
  }
);

export const getProducts = createSelector(
  getProductFeaturestate, state => state.products
);

export const getError = createSelector(
  getProductFeaturestate, state => state.error
)

export function reducer(state = iniitialState, action: ProductActions): ProductState {
  switch (action.type) {
    case ProductActionType.ToggleProductCode:
      return {
        ...state,
        showProductCode: action.payload
      };

    case ProductActionType.SetCurrentProduct:
      return {
        ...state,
        currentProductId: action.payload.id
      };

    case ProductActionType.ClearCurrentProduct:
      return {
        ...state,
        currentProductId: null
      };

    case ProductActionType.InitializeCurrentProduct:
      return {
        ...state,
        currentProductId: 0
      };

    case ProductActionType.LoadSuccess:
      return {
        ...state,
        products: action.payload,
          error: ''
      }

      case ProductActionType.LoadFail:
        return {
          ...state,
          products: [],
            error: action.payload
        }

        case ProductActionType.UpdateProductSuccess:

          const updatedProducts = state.products.map(
            item => action.payload.id == item.id ? action.payload : item);

          return {
            ...state,
            products: updatedProducts,
              currentProductId: action.payload.id,
              error: ''
          }

          case ProductActionType.UpdateProductFail:
            return {
              ...state,
                error: action.payload
            }

            default:
              return state;
  }
}
